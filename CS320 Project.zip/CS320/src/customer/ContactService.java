package customer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.function.BiConsumer;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();
    private final Set<String> contactIds = new HashSet<>();

    public void addContact(Contact contact) {
        // null check
        if (contact == null) {
            throw new IllegalArgumentException("All fields are required");
        }
        // unique id check
        String contactId = contact.getContactId();
        if (contactIds.contains(contactId)) {
            throw new IllegalArgumentException("Contact already exists");
        }
        // contact id validation
        else if (contactId == null || contactId.length() > 10) {
        	throw new IllegalArgumentException("Contact Id may not be null or exceed 10 characters");
        }
        else {
            contacts.put(contactId, contact);
            contactIds.add(contactId);
        }
    }

    public void updateContact(String contactId, BiConsumer<Contact, String> setter, String newValue) {
        Contact contact = getContactById(contactId);
        setter.accept(contact, newValue);
    }

    public void deleteContact(String contactId) {
        // null check
    	if (contactId == null) {
            throw new IllegalArgumentException("Contact id is required");
        }
    	// check if contact id exists
        else if (!contactIds.contains(contactId)) {
            throw new IllegalArgumentException("Contact with id " + contactId + " does not exist");
        }
    	// delete contact
        else {
            contacts.remove(contactId);
            contactIds.remove(contactId);
        }
    }

    public Contact getContactById(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new NoSuchElementException("Contact not found");
        }
        return contact;
    }
}
