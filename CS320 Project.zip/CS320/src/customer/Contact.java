package customer;
public class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        validateName(firstName, "first name");
        validateName(lastName, "last name");
        validatePhone(phone);
        validateAddress(address);

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // getters
    public String getContactId() { return contactId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }

    // setters
    public void setFirstName(String firstName) {
        validateName(firstName, "first name");
        this.firstName = firstName;
    }
    public void setLastName(String lastName) {
        validateName(lastName, "last name");
        this.lastName = lastName;
    }
    public void setPhone(String phone) {
        validatePhone(phone);
        this.phone = phone;
    }
    public void setAddress(String address) {
        validateAddress(address);
        this.address = address;
    }

    // validation methods
    private void validateName(String name, String firstOrLast) {
        if (name == null || name.length() > 10) {
            throw new IllegalArgumentException(
                    "Contact " + firstOrLast + " field may not be empty or exceed 10 characters"
            );
        }
    }
    private void validatePhone(String phone) {
        if (phone == null || phone.length() != 10 || !phone.matches("\\d+")) {
            throw new IllegalArgumentException("Contact phone number must be 10 digits and contain only numbers");
        }
    }
    private void validateAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Contact address field may not be empty or exceed 30 characters");
        }
    }
}
