package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import customer.Contact;
import customer.ContactService;

class ContactTest {
	
	@Test
	void testUpdate() {
		ContactService contactService = new ContactService();
		
		Contact contact = new Contact("1", "first", "last", "1234567890", "123 main place");
		contactService.addContact(contact);
		
		// test updating first name
		contactService.updateContact("1", Contact::setFirstName, "john");
		
		Contact updatedContact = contactService.getContactById("1");
		assertEquals("john", updatedContact.getFirstName());
	}
}
