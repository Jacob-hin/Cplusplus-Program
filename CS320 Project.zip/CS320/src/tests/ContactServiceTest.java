package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import customer.Contact;
import customer.ContactService;

class ContactServiceTest {

	@Test
	void testNewContact() {
		ContactService contactService = new ContactService();
		// add new contact
		Contact expectedContact = new Contact("1", "first", "last", "1234567890", "123 main place");
		contactService.addContact(expectedContact);
		
		// retrieve contact by id and compare to added contact
		Contact actualContact = contactService.getContactById("1");
		assertEquals(expectedContact, actualContact);
	}
	
	@Test
	void testValidateLength() {
		ContactService contactService = new ContactService();
		// id exceeds 10 characters
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("overtencharacters", "first", "last", "1234567890", "123 main place"));
		});
		// first name exceeds 10 characters
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("1", "overtencharacters", "last", "1234567890", "123 main place"));
		});
		// last name exceeds 10 characters
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("1", "first", "overtencharacters", "1234567890", "123 main place"));
		});
		// phone number does not equal 10 characters
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("1", "first", "last", "999999999999", "123 main place"));
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("1", "first", "last", "999999999", "123 main place"));
		});
		// address exceeds 30 characters
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("1", "first", "last", "1234567890", "1234 south north east west main place drive"));
		});
	}
	
	@Test
	void deleteContact() {
		ContactService contactService = new ContactService();
		contactService.addContact(new Contact("1", "first", "last", "1234567890", "123 main place"));
		
		// delete and verify erasure of contact
		contactService.deleteContact("1");
		assertThrows(NoSuchElementException.class, () -> {
			contactService.getContactById("1");
		});
	}
	
	@Test
	void testUniqueId() {
		// add new contact
		ContactService contactService = new ContactService();
		contactService.addContact(new Contact("1", "first", "last", "1234567890", "123 main place"));
		
		// attempt to add duplicate contact id
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("1", "john", "smith", "9999999999", "234 park drive"));
		});
	}
	
	@Test
	void testNotNull() {
		ContactService contactService = new ContactService();
		// id is null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact(null, "first", "last", "1234567890", "123 main place"));
		});
		// first name is null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("1", null, "last", "1234567890", "123 main place"));
		});
		// last name is null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("1", "first", null, "1234567890", "123 main place"));
		});
		// phone number is null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("1", "first", "last", null, "123 main place"));
		});
		// address is null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(new Contact("1", "first", "last", "1234567890", null));
		});
	}
}
