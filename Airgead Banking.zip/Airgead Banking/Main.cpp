#include <cmath>
#include <iomanip>
#include <iostream>
using namespace std;

//Handles data input from user
void DataInput(double& investment, double& deposit, double& interest, int& years) {
    int i = 0;

    cout << "---------------------------" << endl;
    cout << "-------- Data Input--------" << endl;

    //Loops through variable assignment for input validation
    while (i < 4) {
        switch (i) {
            //assigns user input to initial investment
        case 0:
            cout << "Initial Investment Amount: $";
            cin >> investment;
            if (investment < 0) {
                cout << endl << "Invalid initial investment." << endl << endl;
            }
            else {
                i++;
                cout << endl;
            } break;
            //assigns user input to monthly deposit
        case 1:
            cout << "Monthly Deposit: $";
            cin >> deposit;
            if (deposit < 0) {
                cout << "Invalid monthly deposit." << endl;
            }
            else {
                i++;
                cout << endl;
            } break;
            //assigns user input to annual interest
        case 2:
            cout << "Annual Interest: %";
            cin >> interest;
            if (interest < 0 || interest > 100) {
                cout << endl << "Invalid interest percentage." << endl << endl;
            }
            else {
                interest = interest / 100;
                i++;
                cout << endl;
            } break;
            //assigns user input to number of years
        case 3:
            cout << "Number of years: ";
            cin >> years;
            if (years < 0) {
                cout << "Invalid number of years." << endl;
            }
            else {
                i++;
                cout << endl;
            } break;
        default:
            break;
        }
    }
}

//function to print years, year-end balance, and interest earned for calculation functions
void printDetails(int year, double yearEndBalance, double interestEarned) {
    static bool first = true;

    //prints header first time function is called by calculateBalanceWithoutMonthlyDeposit function
    if (year == 1 && first == true) {
        cout << "Balance and interest Without Additional Monthly Deposits" << endl;
        first = false;
    }
    //prints header first time function is called by calculateBalanceWithMonthlyDeposit function
    else if (year == 1 && first == false) {
        cout << "Balance and interest With Additional Monthly Deposits" << endl;
    }
    //prints bottom of header first time either function calls printDetails
    if (year == 1) {
        cout << "========================================================" << endl
            << "Year\t" << "Year End Balance \t" << "Year End Earned Interest" << endl
            << "--------------------------------------------------------" << endl;
    }
    //prints formatted year, year-end balance, and interest earned
    cout << setw(1) << year
        << "\t$" << fixed << setprecision(2) << setw(10) << left << yearEndBalance
        << "\t\t$" << fixed << setprecision(2) << setw(10) << left << interestEarned
        << endl;
    cout << "--------------------------------------------------------" << endl << endl;
}

//calculates balance and interest earned without monthly deposits
double calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double interestRate, int numberOfYears) {
    int yearIndex = 1;
    double balance = initialInvestment;
    double monthlyRate = interestRate / 12;
    double interestEarnedWithoutDeposit = 0;

    //loops for each year up to the value of user-assigned years
    while (yearIndex <= numberOfYears) {
        double temp = balance;
        //calculates balance from compounded monthly interest rate
        balance = balance * pow((1 + monthlyRate), 12);
        //calculates interest earned based on new balance
        interestEarnedWithoutDeposit = balance - temp;
        //calls printDetails function to output variables
        printDetails(yearIndex, balance, interestEarnedWithoutDeposit);
        yearIndex++;
    }
    return balance;
}

//calculates balance and interest earned with monthly deposits
double calculateBalanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears) {
    int yearIndex = 1;
    double balance = initialInvestment;
    double rateComp = interestRate / 12;
    double interestEarnedWithDeposit;

    //loops for each year up to the value of user-assigned years
    while (yearIndex <= numberOfYears) {
        double temp = balance;
        //calculates balance from compounded monthly interest rate with monthly contributions
        balance = balance * pow((1 + rateComp), 12)
            + monthlyDeposit * (pow((1 + rateComp), 12) - 1) / rateComp * (1 + rateComp);
        //calculates interest earned based on new balance
        interestEarnedWithDeposit = balance - temp - monthlyDeposit * 12;
        //calls printDetails function to output variables
        printDetails(yearIndex, balance, interestEarnedWithDeposit);
        yearIndex++;
    }
    return balance;
}

int main() {
    double initialInvestment = 0;
    double monthlyDeposit = 0;
    double interestRate = 0;
    int years = 0;

    //calls function to gather user input and assign variables for calculations
    DataInput(initialInvestment, monthlyDeposit, interestRate, years);

    //requests user input to continue
    cout << "Press any key to continue . . ." << endl << endl;
    cin.ignore();
    cin.get();

    //calls calculation functions, passing user inputted variables as parameters
    calculateBalanceWithoutMonthlyDeposit(initialInvestment, interestRate, years);
    calculateBalanceWithMonthlyDeposit(initialInvestment, monthlyDeposit, interestRate, years);

    return 0;
}
