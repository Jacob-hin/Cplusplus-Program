package com.example.projecttwo.ui.theme.database

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.projecttwo.R

data class InventoryItem(
    val sku: String,
    val name: String,
    val quantity: Int
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryGrid(
    viewModel: InventoryViewModel = viewModel(),
    onAddItemClick: () -> Unit
) {
    val items by viewModel.items.collectAsState()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onAddItemClick,
                containerColor = colorResource(id = R.color.coral), contentColor = Color.White) {
                Icon(Icons.Default.Add, contentDescription = "Add Item")
            }
        },
        topBar = {
            TopAppBar(
                title = {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "Inventory",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }
            )
        },
        content = { padding ->
            Column(modifier = Modifier
                .padding(padding)
                .padding(16.dp)) {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Text("SKU", modifier = Modifier.weight(1f)
                        , fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        color = colorResource(id = R.color.blue))
                    Text("Name", modifier = Modifier.weight(1f)
                        , fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        color = colorResource(id = R.color.blue))
                    Text("Qty", modifier = Modifier.weight(1f)
                        , fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        color = colorResource(id = R.color.blue))
                    Spacer(modifier = Modifier.width(40.dp))
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn {
                    items(items) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.sku, modifier = Modifier.weight(1f))
                            Text(item.name, modifier = Modifier.weight(1f))
                            Text(item.quantity.toString(), modifier = Modifier.weight(1f))
                            IconButton(onClick = { viewModel.deleteItem(item) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }
    )
}
