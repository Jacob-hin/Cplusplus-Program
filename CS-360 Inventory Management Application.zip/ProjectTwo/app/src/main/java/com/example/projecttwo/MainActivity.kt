package com.example.projecttwo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.projecttwo.ui.theme.database.AddProductScreen
import com.example.projecttwo.ui.theme.database.InventoryGrid
import com.example.projecttwo.ui.theme.database.InventoryViewModel
import com.example.projecttwo.ui.theme.login.LogInScreen
import com.example.projecttwo.ui.theme.smsPerm.SMSPermissionScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val navController = rememberNavController()
                val viewModel: InventoryViewModel = viewModel()

                NavHost(navController = navController, startDestination = "login") {
                    composable("login") {
                        LogInScreen(
                            onSignInClick = { navController.navigate("smsPermission") }
                        )
                    }
                    composable("smsPermission") {
                        SMSPermissionScreen(
                            permissionDenied = { navController.navigate("inventory") }
                        )
                    }
                    composable("inventory") {
                        InventoryGrid(
                            viewModel = viewModel,
                            onAddItemClick = {
                                navController.navigate("addItem")}
                        )
                    }
                    composable("addItem") {
                        AddProductScreen(
                            viewModel = viewModel,
                                onItemAdded = {
                                    navController.popBackStack()}
                        )
                    }
                }
            }
        }
    }
}