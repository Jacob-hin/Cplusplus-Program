package com.example.projecttwo.ui.theme.database

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel


@Composable
fun AddProductScreen(
    viewModel: InventoryViewModel = viewModel(),
    onItemAdded: () -> Unit
) {

    val sku = remember { mutableStateOf("") }
    val name = remember { mutableStateOf("") }
    val quantityText = remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally

    ) {
        Text("Add New Item", fontSize = 28.sp, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = sku.value,
            onValueChange = { newValue -> sku.value = newValue },
            label = { Text("SKU") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = name.value,
            onValueChange = { newValue -> name.value = newValue },
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = quantityText.value,
            onValueChange = { newValue -> quantityText.value = newValue },
            label = { Text("Quantity") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
        )

        Button(
            onClick = {
                val quantity = quantityText.value.toIntOrNull() ?: 0

                viewModel.addItem(InventoryItem(sku.value, name.value, quantity))

                onItemAdded()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("Save")
        }
    }
}
