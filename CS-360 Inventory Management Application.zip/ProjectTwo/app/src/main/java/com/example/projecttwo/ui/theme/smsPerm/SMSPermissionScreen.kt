package com.example.projecttwo.ui.theme.smsPerm

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SMSPermissionScreen(
    permissionDenied: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "SMS Permission is required to send messages.",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        val permissionGranted = false

        if (permissionGranted) {
            Text(
                text = "Permission granted! You will now receive SMS messages",
                color = Color.Green
            )
        } else {
            Text(
                text = "Permission not granted. Please allow SMS access.",
                color = Color.Red
            )
            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {permissionDenied() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Blue)
            ) {
                Text("Grant SMS Permission")
            }
        }
    }
}

