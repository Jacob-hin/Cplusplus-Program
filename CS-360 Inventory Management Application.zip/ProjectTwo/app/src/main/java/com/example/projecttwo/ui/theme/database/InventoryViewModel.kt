package com.example.projecttwo.ui.theme.database

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

class InventoryViewModel : ViewModel() {

    private val _items = MutableStateFlow<List<InventoryItem>>(emptyList())
    val items: StateFlow<List<InventoryItem>> = _items

    fun addItem(item: InventoryItem) {
        _items.update { currentItems -> currentItems + item }
    }

    fun deleteItem(item: InventoryItem) {
        _items.update { currentItems -> currentItems - item }
    }
}
